<?php
include("menu.php");


?>



<!DOCTYPE html>
<html>
<head>
<title>W3.CSS Template</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<style>
body,h1 {
  font-family: "Raleway", sans-serif}
body, html {height: 100%}
.bgimg {
  min-height: 100%;
  background-position: center;
  background-size: cover;
  background-color:;
}
h1,p
{
    color:black;
}


</style>
</head>
<body>

<div class="bgimg w3-display-container w3-animate-opacity w3-text-white">
  
  <div class="w3-display-middle">
    <h1 class="w3-jumbo w3-animate-top">COMING SOON</h1>
    
    <p class="w3-large w3-center">My website will be launched really soon.So keep Waiting......</p>
  </div>
 
</div>

</body>
</html>
