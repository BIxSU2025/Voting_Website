<?php

$server="localhost";
$username="root";
$password="";
$db="bimochan";

$con=mysqli_connect($server,$username,$password,$db);
?>