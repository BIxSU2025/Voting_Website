<!-- 1)cookie store data in client device while session store data in server machine.
 .....2)cookie and session are super global variable in php(jata bata pani access garna milney) 
 ....3)user tracking-->
 through the cookies you can control the user activities.
 