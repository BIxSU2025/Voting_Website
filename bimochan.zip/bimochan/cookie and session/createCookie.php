<?php
// setcookie(cookiee name,value,expires)
setcookie("tokens","bimochan",time()+60*60*24);
echo "cookie created";
// echo time();//1970 january first



?>