<?php
//starting ma sadhai session start garney.
session_start();
$_SESSION['token']="bimochan";
$_SESSION['username']="admin";
$_SESSION['token']="bimochan";
echo "session created";


?>