<?php

setcookie("tokens","",time()-1);



?>