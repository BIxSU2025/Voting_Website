

<style>
.title
{
    text-align:center;
    font-family: Fantasy;
    font-weight:bold;
}

</style>


<div class="main-content">
<div class="title"><h1>New Account Registration</h1></div>
<div class="content">


<form action="insertNewAccount.php" method="post">





<label for="username">User Name:</label>
<input type="text" name="username" placeholder="Insert a Valid Username"/>


  <label for="password">Password:</label>
 <input type="password" class="pass" name="password" placeholder="Insert a password"/>

 <label for="retype_password">Retype Password:</label>
 <input type="password" class="pass" name="retype_password" placeholder="Insert a password"/>


 <input type="submit" name=""  class="btn success">

</form>
</div>
